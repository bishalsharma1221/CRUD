
module org.example.finaltest2 {
    requires javafx.controls;
    requires javafx.fxml;


    requires com.dlsc.formsfx;
    requires java.sql;

    opens org.example.finaltest2 to javafx.fxml;
    exports org.example.finaltest2;

}